package com.nokia.ent.tooling.reading.pricing.proxy;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Properties;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jetty.servlets.ProxyServlet;

/**
 * This servlet acts as a proxy for other services. It is the target of XHR from
 * JavaScript. It relies on a system property "app.properties" whose value is
 * the location of a .properties file. This properties file is loaded to
 * discover the location of the services we proxy.
 * <p/>
 * This class also implements ServletContextListener so that it can block the
 * startup of the app if the properties file is not found.
 */
public class ProxyingServlet extends HttpServlet implements ServletContextListener {

    private static final long serialVersionUID = -4415410532542830391L;

    private URI secureProxyUri;

    /**
     * This loads and sets the properties. This is done twice because the
     * container will use a separate instance of the class on startup (as
     * ServletContextListener) than to service requests (as HttpServlet).
     */
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        loadProperties();
    }

    /**
     * This loads and sets the properties. This is done twice because the
     * container will use a separate instance of the class on startup (as
     * ServletContextListener) than to service requests (as HttpServlet).
     */
    @Override
    public void init() {
        loadProperties();
    }

    private void loadProperties() {

        String propsLocation = System.getProperty("app.properties");
        System.out.println("Properties location is " + propsLocation);

        try {
            Properties props = new Properties();
            props.load(new FileInputStream(propsLocation));
            secureProxyUri = getSecureProxyUri(props);
        } catch (Exception e) {
            System.out.println("FATAL: Cannot load properties file from " + propsLocation);
            throw new RuntimeException(e);
        }
    }

    private URI getSecureProxyUri(Properties props) throws URISyntaxException {
        String secureProxyUriProperty = props.getProperty("environment.entertainment.proxynation.baseUrl");
        return new URI(secureProxyUriProperty);
    }

    @Override
    protected final void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        ProxyServlet proxy = getProxy(request.getServletPath());

        System.out.println("Request to: [" + request.getRequestURI() + "]");

        if (proxy != null) {
            proxy.init(getServletConfig());
            proxy.service(request, response);

        } else {
            response.setStatus(404);

        }
    }

    private ProxyServlet getProxy(String pathRoot) {

        return new ProxyServlet.Transparent(
                pathRoot, secureProxyUri.getScheme(), secureProxyUri.getHost(), secureProxyUri.getPort(), "/proxy");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
    }

}