package com.nokia.ent.tooling.reading.pricing;

import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.util.Properties;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

public class FilteringFilter implements Filter {

    private VelocityContext context;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

        String appPropertiesPath = System.getProperty("app.properties");

        if (appPropertiesPath == null) {
            throw new ServletException("Did you mean to specify that there were no application properties?");
        }

        Properties properties = new Properties();

        try {
            properties.load(new FileReader(appPropertiesPath));
        } catch (IOException e) {
            throw new ServletException("Failed to load properties from " + appPropertiesPath);
        }

        context = new VelocityContext();

        String serviceToolsBaseUrl = properties.getProperty("service.tools.baseUrl");

        if (serviceToolsBaseUrl == null) {
            throw new ServletException("Missing Service tools base URL from properties");
        }

        context.put("serviceToolsBaseUrl", serviceToolsBaseUrl);

    }

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        if (!(response instanceof HttpServletResponse)) {
            chain.doFilter(request, response);
            return;
        }

        BufferedServletResponseWrapper responseWrapper = new BufferedServletResponseWrapper((HttpServletResponse) response);

        chain.doFilter(request, responseWrapper);

        String content = new String(responseWrapper.getBufferedData());

        StringWriter writer = new StringWriter();

        Velocity.evaluate(context, writer, "JEFFER", content);

        byte[] bytes = writer.toString().getBytes();

        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        httpServletResponse.setStatus(HttpServletResponse.SC_OK);
        httpServletResponse.setContentLength(bytes.length);

        OutputStream stream = httpServletResponse.getOutputStream();

        stream.write(bytes);
        stream.flush();

    }

}
