package com.nokia.ent.tooling.reading.pricing;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletOutputStream;

/**
 * Implementation of {@link ServletOutputStream} that can conveniently be used
 * with a Servlet filter. Writes are delegated to the given {@link OutputStream}
 * allowing data to be captured by that stream before being written to the
 * original servlet response.
 * 
 * @see <a
 *      href="http://download.oracle.com/docs/cd/B32110_01/web.1013/b28959/filters.htm#BCFIAAAH">Understanding
 *      and Using Servlet Filters</a>
 */
public class FilterServletOutputStream extends ServletOutputStream {

    private OutputStream stream;

    public FilterServletOutputStream(OutputStream stream) {
        this.stream = stream;
    }

    @Override
    public void write(int b) throws IOException {
        stream.write(b);
    }

    @Override
    public void write(byte[] b) throws IOException {
        stream.write(b);
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        stream.write(b, off, len);
    }

}
