package com.nokia.ent.tooling.reading.pricing;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

import org.apache.http.HttpStatus;

/**
 * Implementation of {@link HttpServletResponseWrapper} that buffers response
 * content. This wrapper enables, for instance, a Servlet filter to allow
 * proceeding chain to write response content to this buffered wrapper, then
 * modify that content before writing the the original response.
 * 
 * @see <a
 *      href="http://download.oracle.com/docs/cd/B32110_01/web.1013/b28959/filters.htm#BCFIAAAH">Understanding
 *      and Using Servlet Filters</a>
 */
public class BufferedServletResponseWrapper extends HttpServletResponseWrapper {

    private int status = HttpStatus.SC_OK; // default status

    private final ByteArrayOutputStream output = new ByteArrayOutputStream();

    public BufferedServletResponseWrapper(HttpServletResponse response) {
        super(response);
    }

    public byte[] getBufferedData() {
        return output.toByteArray();
    }

    @Override
    public ServletOutputStream getOutputStream() throws IOException {
        return new FilterServletOutputStream(output);
    }

    @Override
    public PrintWriter getWriter() throws IOException {
        return new PrintWriter(output, true);
    }

    @Override
    public void setStatus(int sc) {
        this.status = sc;
        super.setStatus(sc);
    }

    @Override
    public void setStatus(int sc, String sm) {
        this.status = sc;
        super.setStatus(sc, sm);
    }

    @Override
    public void sendError(int sc) throws IOException {
        this.status = sc;
        super.sendError(sc);
    }

    @Override
    public void sendError(int sc, String msg) throws IOException {
        this.status = sc;
        super.sendError(sc, msg);
    }

    @Override
    public void sendRedirect(String location) throws IOException {
        this.status = HttpStatus.SC_MOVED_PERMANENTLY;
        super.sendRedirect(location);
    }

    public int getStatus() {
        return this.status;
    }

}
