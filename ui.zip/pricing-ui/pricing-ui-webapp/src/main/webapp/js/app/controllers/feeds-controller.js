/*globals "console", "$", "angular", "requestUriCreator" */

function FeedsController($xhr, $defer, requestUriCreator, feedValidatorService) {
	this.$xhr = $xhr;
	this.$xhr.defaults.headers.put['Content-Type'] = 'application/vnd.nokia.ent.feedlist+json';
	this.$defer = $defer;
	this.requestUriCreator=requestUriCreator;
    this.feedValidatorService = feedValidatorService;
	
	this.categories = [];
	this.originalCategories = [];
	this.disabledAddCategoryBtn = false;
    this.categoriesLimit = 10;
    this.feedsLimit = 4;
    this.territory = '';
    this.showInfoMessage = false;
    this.infoMessage = '';
    this.infoMessageClass = '';
	
	this.$watch('territory', this.getCategories);
	
}

FeedsController.prototype = {
    
	deleteCategory : function(categoryId) {
		angular.Array.remove(this.categories, this.categories[categoryId]);
	},

	getCategories : function() {
	    
	    if(angular.isDefined(this.territory) && this.territory !== ''){
	        var uri = this.requestUriCreator.feedsUri(this.territory );
	        
	        this.$xhr('GET', uri, this.getSuccess, this.handleError);
	    } else {
	        this.categories = [];
	    }

	},

	getSuccess : function(code, response) {
		this.categories = response.items;
		this.originalCategories = angular.Object.copy(this.categories);
	},
	
	putSuccess : function(code, response) {
        this.setInfoMessage('News feeds successfully saved for the territory "' + this.territory + '"', 5000, 'success');
        this.$defer(this.getCategories, 500);
	},

	handleError : function(code, response) {
	    if(code === 404){
	        this.categories = [];
	        this.originalCategories = [];
	    } else {
          console.log('An error occurred whilst retrieving feeds. Status code was ' + code);
          this.setInfoMessage('An error ocurred on the last request.', 10000, 'error');
	    }
	},

	moveUpCategory : function(categoryId) {

		var category = this.categories[categoryId], categoryBefore = null;

		if (categoryId === 0 && angular.Array.count(this.categories) > 1) {

			categoryBefore = this.categories[angular.Array
					.count(this.categories) - 1];

			this.categories[categoryId] = categoryBefore;
			this.categories[angular.Array.count(this.categories) - 1] = category;

		} else if (categoryId !== 0) {

			categoryBefore = this.categories[categoryId - 1];

			this.categories[categoryId] = categoryBefore;
			this.categories[categoryId - 1] = category;

		}

	},

	moveDownCategory : function(categoryId) {

		var category = this.categories[categoryId], categoryAfter = null, lastIndex = angular.Array
				.count(this.categories) - 1;

		if (categoryId === lastIndex && categoryId !== 0) {

			categoryAfter = this.categories[0];

			this.categories[categoryId] = categoryAfter;
			this.categories[0] = category;

		} else if (categoryId !== lastIndex
				&& angular.Array.count(this.categories) > 1) {

			categoryAfter = this.categories[categoryId + 1];

			this.categories[categoryId] = categoryAfter;
			this.categories[categoryId + 1] = category;

		}

	},
	
	addNewCategory : function () {
	    if(this.categories.length < this.categoriesLimit){
	        this.categories.push(this.createEmptyCategory());
	    }
	    
	},
	
	createEmptyCategory : function () {
	    return {
            "name" : "",
            "feeds" : []
            };
	},
	
	addNewFeed : function (categoryId) {
	    var category = this.categories[categoryId],
	    feeds = category.feeds;
	    
	    if(feeds.length < this.feedsLimit){
	        feeds.push({});
	    }
	},
	
	removeFeed : function(categoryId, feedId) {
	    var category = this.categories[categoryId];
	    category.feeds.splice(feedId,1);
	},

	cancelModifications : function() {
	    this.getCategories();
	},
	
	validateFields : function() {
	    var i, j, feeds, formValid = true;

	    categories:
	    for (i in this.categories) {
	        if (this.categories[i].name === '') {
	            formValid = false;
	            break;
	        }
	        feeds = this.categories[i].feeds;
	        for (j in feeds) {
	            if (feeds[j].uri === '' || feeds[j].name === '') {
	                formValid = false;
	                break categories;
	            }
	        }
	    }
	    if (formValid) {
	        this.saveCategories();
	    } else {
	        this.setInfoMessage('Validation error. Fill in the required fields.', 10000, 'error');
	    }
	},
	
	setInfoMessage : function(message, timeShown, type){
	    this.showInfoMessage = true;
        this.infoMessage = message;
        this.infoMessageClass = 'alert alert-' + type;
        this.$defer(this.clearInfoMsg , timeShown);
	},
	
	clearInfoMsg : function() {
	    this.showInfoMessage = false;
	},
	
	saveCategories : function() {
	    var uri = this.requestUriCreator.feedsUri(this.territory );	        
	    
        this.$xhr('PUT', uri,this.wrapCategories(), this.putSuccess, this.handleError);
        
	},
	
	wrapCategories : function(){
		return {"items":this.categories};
	},

    /** 
     * Holds meta information about the state of the validation as we can't store this
     * directly against the existing category object as we send this straight back to 
     * the webservice
     */
    validationState : [],
    numFeeds : 0,
    finishedFeeds : 0,

    validateAllFeeds : function() {
        var i, j, feeds;

        this.cleanupValidate();

	    for(i in this.categories) {
	        for(j in this.categories[i].feeds) {
                this.numFeeds++;
                this.validateFeed(i, j);
	        }
	    }
    },

    validateSingleFeed : function(categoryId, feedId) {
        this.cleanupValidate();
        this.numFeeds++;
        this.validateFeed(categoryId, feedId);  
    },

    /** show / hide the validation progress bar */
    validateAllFeedsState : function() {
        if (this.numFeeds === this.finishedFeeds) {
            return 'hide';
        }
        return 'show';
    },

    /** how far complete is the validation progress bar */
    validateAllFeedsProgress : function() {
        if (this.numFeeds === 0) {
            return 100;
        } 
        return this.finishedFeeds / this.numFeeds * 100;
    },

    cleanupValidate : function(timeout) {
        var self = this;
        if (timeout === undefined) {
            return self.performCleanupValidate();
        }
        this.$defer(function() {
            self.performCleanupValidate();
        }, timeout);
    },

    performCleanupValidate : function() {
        this.numFeeds = 0;
        this.finishedFeeds = 0;
        this.validationState = [];
    },

	validateFeed : function(categoryId, feedId) {
	    var category, currentFeed, reqCode, reqResponse, metaId, self = this;

        metaId = this.getMetaId(categoryId, feedId);
	    currentFeed = this.getCurrentFeed(categoryId, feedId);

        this.validationState[metaId] = {desc : 'validating', cssClass : 'default'};

        this.feedValidatorService(currentFeed.uri, function(state) {
            self.validationState[metaId] = state;
            self.finishedFeeds++;
            if (self.finishedFeeds === self.numFeeds) {
                self.cleanupValidate(10000);
            }
        });
	},

    getCurrentFeed : function(categoryId, feedId) {
	    var category = this.categories[categoryId];
	    return category.feeds[feedId];
    },

    /** Gives us the key into the meta information array for a feed */
    getMetaId : function(categoryId, feedId) {
        return categoryId.toString() + feedId;
    },

    /** Return the class for a uri's validation label */
    getValidationClass : function(categoryId, feedId) {
        var metaId = this.getMetaId(categoryId, feedId);
        if (this.validationState[metaId] !== undefined) {
            return this.validationState[metaId].cssClass;
        }
        return 'hide';
    },

    /** Return the text description for a uri's validation label */
    getValidationDesc : function(categoryId, feedId) {
        var metaId = this.getMetaId(categoryId, feedId);
        if (this.validationState[metaId] !== undefined) {
            return this.validationState[metaId].desc;
        }
        return '';
    }

};

FeedsController.$inject = ['$xhr', '$defer', 'requestUriCreator', 'feedValidatorService'];
