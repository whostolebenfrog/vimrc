/*globals "console", "$", "angular", "escape" */

function HistoryController($xhr, deliveryBaseUrl, $route, $location ) {
    
	this.$xhr = $xhr;
    this.deliveryBaseUrl = deliveryBaseUrl;
    this.$route = $route;
    this.$location = $location;
    this.isWarning = false;
    this.booksOrig = null;
    this.territory = "";
    this.searchTerm = "";
    
    $("#fromStart").datepicker();
    $("#toEnd").datepicker();
    $("#fromStart").datepicker("option", "dateFormat", 'dd M yy');
    $("#toEnd").datepicker("option", "dateFormat", 'dd M yy');
    
    this.getOverridePrices();
    
    this.$watch(function () {
        return $route.current.params;
    }, function (params) {
        this.territory = params.territory;
        this.isWarning = params.warning;
        this.searchTerm = params.searchTerm;
        if(params.fromStart) {
            $("#fromStart").datepicker("setDate", new Date(params.fromStart));
        }
         if(params.toEnd) {
            $("#toEnd").datepicker("setDate", new Date(params.toEnd));
        }
    });
}

HistoryController.prototype = {
    
    territoryChange : function() {
	    var hashSearch = this.$location.hashSearch;
	    if (this.territory) {
            hashSearch.territory = this.territory;
        } else {
            delete(hashSearch.territory);
        }
        this.$location.updateHash(this.$location.hashPath, hashSearch);
	
    },
    
    fromStartChange : function() {
	    var hashSearch = this.$location.hashSearch;
	    if ($("#fromStart").datepicker("getDate")) {
            hashSearch.fromStart = $("#fromStart").datepicker("getDate");
        } else {
            delete(hashSearch.fromStart);
        }
        this.$location.updateHash(this.$location.hashPath, hashSearch);
	
    },
    
    toEndChange : function() {
	    var hashSearch = this.$location.hashSearch;
	    if ($("#toEnd").datepicker("getDate")) {
            hashSearch.toEnd = $("#toEnd").datepicker("getDate");
        } else {
            delete(hashSearch.toEnd);
        }
        this.$location.updateHash(this.$location.hashPath, hashSearch);
	
    },
    
    warningChange : function() {
	    var hashSearch = this.$location.hashSearch;
	    if (this.isWarning) {
            hashSearch.warning = this.isWarning;
        } else {
            delete(hashSearch.warning);
        }
        this.$location.updateHash(this.$location.hashPath, hashSearch);
	
    },
    
    searchTermChange : function() {
	    var hashSearch = this.$location.hashSearch;
	    if (this.searchTerm) {
            hashSearch.searchTerm = this.searchTerm;
        } else {
            delete(hashSearch.searchTerm);
        }
        this.$location.updateHash(this.$location.hashPath, hashSearch);
	
    },
    
    createPageUrl : function () {
        return this.$location.href.replace('territory=' + escape(this.territory).replace('warning='+escape(this.isWarning)).replace('searchTerm='+escape(this.searchTerm)));
    },

    getOverridePrices : function() {
        var url = this.deliveryBaseUrl + "/override/details?callback=JSON_CALLBACK";
        console.log(url);
        this.$xhr("JSON", url, this.getSuccess, this.getError);
    },

    getSuccess : function(code, response) {
        this.books = response;
        this.booksOrig = this.books;
        this.filterBooks();
    },

    getError : function(code, response) {
        console.log('An error occurred whilst retrieving overriden books. Status code was ' + code);
    },
    
    filterBooks : function() {
        
        var bookList = this.booksOrig;

        bookList = this.filterByWarning(bookList);
        bookList = this.filterByTerritory(bookList);
        bookList = this.filterByName(bookList);
        bookList = this.filterByStartTime(bookList);
        bookList = this.filterByEndTime(bookList);
        
        this.books = bookList;
        this.pageUrl = escape(this.createPageUrl());
    },
    
    filterByWarning : function(bookList) {
	
        var self = this;
	
        if(this.isWarning)
        {
            return  Array.filter(bookList, function(book) {
	        return book.warning === self.isWarning;
                });	
        }else {
              return bookList;
        }
      
    },
    
    filterByTerritory : function(bookList) {

        var self = this;


        if(this.territory) {
                return Array.filter(bookList, function(book) {
                return book.territory === self.territory;
        });	
        } else {
            return bookList;
        }

    },
    
    filterByName : function(bookList) {
	
        var self = this;
        
        if(this.searchTerm ) {
              return Array.filter(bookList, function(book) {

                 if((book.bookName.toUpperCase()).indexOf(self.searchTerm.toUpperCase())>-1) {
                     return true;
                 }
                    return false;	
                 });	
         } else {
              return bookList;
         }
    },
    
    filterByStartTime : function(bookList) {
	
       var self = this;
       
       return Array.filter(bookList, function(book) {
        
            var bookDate = new Date(book.date), startDate = $("#fromStart").datepicker("getDate");

            if(startDate === null) {
                return true;
            }
            return bookDate >= startDate;
       });
	
    },
        
    filterByEndTime : function(bookList) {
	
        var self = this;
        
        return Array.filter(bookList, function(book) {
        
            var bookDate = new Date(book.date), endDate = $("#toEnd").datepicker("getDate");
            if (endDate === null) {
                return true;
            }
            endDate.setDate(endDate.getDate()+1);
            
            return bookDate <= endDate;
         });

    },
    
    clear : function() {
    
        this.territory = "";
        this.searchTerm = "";
        $("#toEnd").datepicker("setDate", null);
        $("#fromStart").datepicker("setDate", null);
        this.isWarning = false;
        
        this.getOverridePrices();
        this.filterBooks();
    } 
    



    
   

};



HistoryController.$inject = [ '$xhr', 'deliveryBaseUrl', '$route', '$location' ];