function MainController($scope, $location) {
    $scope.isActiveNavigation = function(name) {
        if (this.$location.path === '' && name === 'search') {
            return 'active';
        }
        if (this.$location.path === '/' + name) {
            return 'active';
        }
        if (this.$location.path.indexOf('override') > -1 && name === 'override') {
            return 'active';
        }
        
        return '';
    }
}
MainController.$inject = [ '$scope', '$location' ];
