/*globals "console", "$", "escape", "angular", "ORU" */

function SearchController($xhr, $location, $defer, $route, searchBaseUrl, itemsPerPage, deliveryBaseUrl) {

    this.$xhr = $xhr;
    this.$xhr.defaults.headers.put['Content-Type'] = 'application/json';

    this.$location = $location;
    this.$defer = $defer;
    this.$route = $route;
    this.searchBaseUrl = searchBaseUrl;
    this.itemsPerPage = itemsPerPage;
    this.deliveryBaseUrl = deliveryBaseUrl;
    this.wait = 0;
    this.searchTerm = '';
    this.selectedEntityId = 0;
    this.selectedEntity = null;
    this.results = '';
    this.currentPage = 1;
    this.maxPage = 0;
    this.territory = null;

    this.$watch('territory', function() {
        this.changeTerritory();
    });

    this.$watch('selectedEntityId', function() {
        this.getSelectedEntity();
    });

    this.$watch(function () {
        return $route.current.params;
    }, function (params) {
        this.territory = params.territory;
        this.searchTerm = params.searchTerm;
           this.search();
    });
}
SearchController.prototype = {

     territoryChange : function() {
	    var hashSearch = this.$location.hashSearch;
	    if (this.territory) {
            hashSearch.territory = this.territory;
        } else {
            delete(hashSearch.territory);
        }
        this.$location.updateHash(this.$location.hashPath, hashSearch);
        
    },   
    
    searchTermChange : function() {
	    var hashSearch = this.$location.hashSearch;
	    if (this.searchTerm) {
            hashSearch.searchTerm = this.searchTerm;
        } else {
            delete(hashSearch.searchTerm);
        }
        this.$location.updateHash(this.$location.hashPath, hashSearch);
    },

    resetEntity : function() {
        this.currentPage = 1;
        this.selectedEntityId = 0;
        this.selectedEntity = null;
    },

    changeTerritory : function() {
        this.selectedEntityId = 0;

    },

    type : function() {
        this.resetEntity();
        this.wait += 1;
        this.$defer(this.waitNoMore, 250);
    },

    waitNoMore : function() {
        this.wait -= 1;
        if (!this.wait) {
            if (this.searchTerm.length === 0) {
                this.results = [];
                return;
            }

        }
    },

    pageForwards : function() {
        if (this.currentPage === this.maxPage) {
            return;
        }

        this.currentPage = this.currentPage + 1;
        this.search();
    },

    pageBackwards : function() {
        if (this.currentPage === 1) {
            return;
        }

        this.currentPage = this.currentPage - 1;
        this.search();
    },

    search : function() {
        if (!this.searchTerm) {
            return;
        }
        
        if (!this.territory) {
            return;
        }
        var url = this.searchBaseUrl + '/' + escape(this.territory) + '/books?q=' + escape(this.searchTerm) + '&callback=JSON_CALLBACK&itemsperpage=' + this.itemsPerPage + '&startindex='
                + (this.itemsPerPage * (this.currentPage - 1)) + '&f-type=book';
        this.searchTermChange();
        console.log(url);
        this.$xhr('JSON', url, this.searchSuccess, this.searchError);
    },

    searchSuccess : function(code, response) {
        var results, remainder;
        this.results = response.items;
        results = response.paging.total;
        remainder = results % this.itemsPerPage;

        if (remainder === 0) {
            this.maxPage = results / this.itemsPerPage;
        } else {
            this.maxPage = ((results - remainder) / this.itemsPerPage) + 1;
        }
        this.searchTermChange();
    },

    searchError : function(code, response) {
        console.log('An error occurred while searching. Status code was ' + code);
    },

    selectEntity : function(id) {
        console.log(id);
        this.selectedEntityId = id;
    },


    getSelectedEntity : function() {

        this.selectedEntity = null;
        
        if (this.selectedEntityId > 0) {
        this.$location.hashPath = "/override/" + this.territory + "/" + this.selectedEntityId ;
        }
    }

};

SearchController.$inject = [ '$xhr', '$location', '$defer', '$route', 'searchBaseUrl', 'itemsPerPage', 'deliveryBaseUrl' ];
