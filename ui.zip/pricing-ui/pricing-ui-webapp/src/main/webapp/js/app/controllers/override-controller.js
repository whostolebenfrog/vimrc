/*globals "console", "$", "escape", "angular", "ORU" */

function OverrideController($xhr, $location, $defer, $route, searchBaseUrl, deliveryBaseUrl) {

    this.$xhr = $xhr;
    this.$xhr.defaults.headers.put['Content-Type'] = 'application/json';

    this.$location = $location;
    this.$defer = $defer;
    this.$route = $route;
    this.searchBaseUrl = searchBaseUrl;
    this.deliveryBaseUrl = deliveryBaseUrl;
    this.selectedEntityId = 0;
    this.selectedEntity = null;
    this.results = '';
    this.tax = null;
    this.discount = null;
    this.priceOverride = null;
    this.territory = null;
    this.userName = null;
	this.audtiDate = null;
	this.warning = false;
	this.isError = false;

    this.$watch('territory', function() {
        this.changeTerritory();
    });

    this.$watch('selectedEntityId', function() {
        this.getSelectedEntity();
    });

    this.$watch('selectedEntity', function() {
        this.getPriceOverride();
        this.jiggerOverridePriceInput();
    });

    this.$watch('priceOverride', function() {
        this.jiggerOverridePriceButtons();
    });
    
    this.$watch(
            function () {
                return $route.current.params;
            },
            function (params) {
                this.territory = params.territory;
                this.selectedEntityId = params.entityId;
                this.selectEntity(params.entityId);
        
                if(!this.territory || !this.selectedEntityId){
                    this.$location.hashPath = "/search";
                }
            }
    );
}

OverrideController.prototype = {

    resetEntity : function() {
        this.currentPage = 1;
        this.selectedEntityId = 0;
        this.selectedEntity = null;
    },

    changeTerritory : function() {
        if (this.territory !== null) {
            this.getTax();
        }
    },

    type : function() {
        this.resetEntity();
        this.wait += 1;
        this.$defer(this.waitNoMore, 350);
    },

    selectEntity : function(id) {
        this.selectedEntityId = id;
    },

    hasResults : function() {
        if (this.results) {
            return this.results.length;
        }
        return false;
    },

    getSelectedEntity : function() {

        this.selectedEntity = null;
        console.log(this.selectedEntityId);
        if (this.selectedEntityId > 0) {
            var url = this.searchBaseUrl + '/' + escape(this.territory) + '/items/' + this.selectedEntityId + '?callback=JSON_CALLBACK&view=full';
            this.$xhr('JSON', url, this.entitySuccess, this.entityError);
        }
    },

    entitySuccess : function(code, response) {
        this.selectedEntity = response;
        this.isError = false;
        this.getDiscount();
        
        if (this.selectedEntity.wholesaleprices) {
            this.wholesaleprices = ORU.create(this.selectedEntity.wholesaleprices, 4);
        } else {
            this.wholesaleprices = 'No wholesale price defined';
        }

        this.prices = ORU.create(this.selectedEntity.prices, 4);
    },

    entityError : function(code, response) {
	    this.isError = true;
        console.log('An error occurred while retrieving an entity. Status code was ' + code);
    },

    entitySelected : function() {
        return (this.selectedEntityId && this.selectedEntityId !== 0 && this.isError !== true);
    },

    jiggerOverridePriceButtons : function() {
        var value = parseFloat(this.priceOverride);
        if (isNaN(value) || value < 0){
            this.overridePriceButtonDisabled = true;
        } else {
            this.overridePriceButtonDisabled = false;
        }
        if(this.priceOverride !== null){
             if(this.priceOverride.indexOf(",") > -1 )
             {
                this.isComma = true;
                this.overridePriceButtonDisabled = true;
             }else {
                this.isComma = false;
             }
        }
       
    },

    jiggerOverridePriceInput : function() {
        this.overridePriceInputDisabled = (this.selectedEntity === null)
            || (this.selectedEntity.wholesaleprices === undefined)
            || (this.selectedEntity.wholesaleprices.permanentdownload === undefined)
            || (this.selectedEntity.wholesaleprices.permanentdownload.businessmode !== 'b2c');
    },

    getTax : function() {
        if (!this.territory) {
            return;
        }
        
        this.tax = 0;
        var url = this.deliveryBaseUrl + '/tax/' + this.territory + '?callback=JSON_CALLBACK';
        console.log(url);
        this.$xhr('JSON', url, this.getTaxSuccess, this.getTaxError);
    },

    getTaxSuccess : function(code, response) {
        this.tax = response.value;
    },

    getTaxError : function(code, response) {
        console.log('An error occurred while fetching tax. Status code was ' + code);
    },

    getDiscount : function() {
        if (!this.territory) {
            return;
        }
        console.log(this.selectedEntity.category.name.toLowerCase());
        this.discount = 0;
        var url = this.deliveryBaseUrl + '/griddiscount/' + this.territory + "/" + this.selectedEntity.category.name.toLowerCase() + '?callback=JSON_CALLBACK';
        console.log(url);
        this.$xhr('JSON', url, this.getDiscountSuccess, this.getDiscountError);
    },

    getDiscountSuccess : function(code, response) {
        
        this.discount = this.calculateDiscount(response);
    },
    
    calculateDiscount : function(discounts) {
        var wholesalePrice, retailPriceExclVAT,discountBand,rowSize,columnSize,row,column,srp,discount,retailPrice;

        // ((retailPriceExclVAT - wholesalePrice) / retailPriceExclVAT) * 100
        
        wholesalePrice = this.selectedEntity.wholesaleprices.permanentdownload.value;
        retailPrice = this.selectedEntity.prices.permanentdownload.originalvalue;
        retailPriceExclVAT = retailPrice * 100 / (100+this.tax);
        
        discountBand = (retailPriceExclVAT - wholesalePrice) / retailPriceExclVAT * 100;
        console.log("re "+ discountBand);
        rowSize = angular.Object.size(discounts.srpbands, true);
        columnSize = angular.Object.size(discounts.srpbands[0].publisherDiscountBands, true);

        for(row=0; row<rowSize;row++){
            if(discounts.srpbands[row].lowerLimit <= wholesalePrice){
                srp = discounts.srpbands[row].publisherDiscountBands;
            }
        }
        
        for(column=0; column<columnSize; column++){
            if(srp[column].lowerLimit <= discountBand){
                discount=srp[column].retailerDiscount;
            }
                
           
        }
        return discount;
        
    },

    getDiscountError : function(code, response) {
        console.log('An error occurred while fetching discount. Status code was ' + code);
    },

    getPriceOverrideSuccess : function(code, response) {
        if (code === 200) {
            this.priceOverride = response.price.toString().toLocalePrice();
            this.userName = response.userName.toString();
            this.auditDate = response.date.toString();
            this.warning = this.checkPrice();
        } else {
            this.priceOverride = null;
            this.userName = null;
            this.auditDate = null;
        }
    },

    getPriceOverrideError : function(code, response) {
	    this.warning = false;
        console.log('An error occurred while fetching the manual override. Status code was ' + code);
    },

    getPriceOverride : function() {
        this.priceOverride = null;
		this.userName = null;
        this.auditDate = null;

        if (this.selectedEntity !== null) {
            var url = this.deliveryBaseUrl + '/override/' + this.territory + '/' + this.selectedEntity.bookid + '?callback=JSON_CALLBACK';
            console.log(url);
            this.$xhr('JSON', url, this.getPriceOverrideSuccess, this.getPriceOverrideError);
        }
    },

    applyPriceOverrideSuccess : function(code, response) {
         this.getPriceOverride();
},

    applyPriceOverrideError : function(code, response) {
        console.log('An error occurred while applying the manual override. Status code was ' + code);
    },

    applyPriceOverride : function() {

        this.priceOverride = this.priceOverride.toLocalePrice();

        this.warning = this.checkPrice();

        var numericPriceOverride = this.priceOverride.toPriceFloat(), url = this.deliveryBaseUrl + '/override/' + this.territory + '/' + this.selectedEntity.bookid + '?warning=' + this.warning, data = {
            value : numericPriceOverride
        };

        console.log(url);

        this.$xhr('PUT', url, data, this.applyPriceOverrideSuccess, this.applyPriceOverrideError);
    },

    checkPrice : function() {
	
        var wholesalePrice = this.selectedEntity.wholesaleprices.permanentdownload.value;
        wholesalePrice = wholesalePrice * 1.3;
        wholesalePrice = parseFloat(wholesalePrice).toFixed(2);
        


        if(isNaN(this.priceOverride) || this.priceOverride === '') {
            this.warning = false;
        }else
        {
           if(wholesalePrice >= this.priceOverride.toPriceFloat() ) {
             this.warning = true;
             return true;
           }else
           {
             this.warning = false;
             return false;
           }
        }
    },

    removePriceOverrideSuccess : function(code, response) {
        this.priceOverride = null;
		this.userName = null;
        this.auditDate = null;
        this.warning = false;
    },

    removePriceOverrideError : function(code, response) {
        console.log('An error occurred while removing the manual override. Status code was ' + code);
    },

    removePriceOverride : function() {
        var url = this.deliveryBaseUrl + '/override/' + this.territory + '/' + this.selectedEntity.bookid;
        console.log(url);

        this.$xhr('DELETE', url, this.removePriceOverrideSuccess, this.removePriceOverrideError);
    }
};

OverrideController.$inject = [ '$xhr', '$location', '$defer', '$route', 'searchBaseUrl', 'deliveryBaseUrl' ];
