/*globals console, angular */

var feedsModule = angular.module('feeds', []);
feedsModule.factory('requestUriCreator', function() {

	var proxyRoot = "/proxy",
        uriCreator = {}, 
        feedsUriTemplate = proxyRoot+ '/eapi/1.x/<<territory>>/feeds/private';

	/**
	 * Method to get the URI required for retrieving feeds.
	 */
	uriCreator.feedsUri = function(territory) {

		var uri = '';

		if (!angular.isString(territory)) {
			return false;
		}

		// valid args, replace the tokens in the base uri
		uri = feedsUriTemplate.replace(/<<territory>>/, territory);

		return uri;

	};

	// PUBLIC INTERFACE
	return uriCreator;

});
