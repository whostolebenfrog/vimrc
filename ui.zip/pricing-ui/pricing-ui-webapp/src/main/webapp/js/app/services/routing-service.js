angular.module('phonecat', ['phonecatFilters']).
  config(['$routeProvider', function($routeProvider) {
  $routeProvider.
      when('/phones', {template: 'partials/phone-list.html',   controller: PhoneListCtrl}).
      when('/phones/:phoneId', {template: 'partials/phone-detail.html', controller: PhoneDetailCtrl}).
      otherwise({redirectTo: '/phones'});
}]);


angular.module('route', [], function($routeProvider) {
	var self = this;
    this.$routeProvider = $routeProvider;
    this.$routeProvider.when('', {
        template : 'search.html'
    });
    this.$routeProvider.when('/override/:territory/:entityId', {
        template : 'override.html'
    });
    this.$routeProvider.when('/override', {
        template : 'override.html'
    });
    this.$routeProvider.when('/override/:territory', {
        template : 'search.html'
    });
    this.$routeProvider.when('/override/:territory/', {
        template : 'search.html'
    });
    this.$routeProvider.when('/discount/:territory/:type', {
        template : 'discount.html'
    });
    this.$routeProvider.when('/discount', {
        template : 'discount.html'
    });
    this.$routeProvider.when('/tax', {
        template : 'tax.html'
    });
    this.$routeProvider.when('/history', {
        template : 'history.html'
    });
    this.$routeProvider.when('/search', {
        template : 'search.html'
    });
    this.$routeProvider.when('/feeds', {
        template : 'feeds.html'
    });
    /* TODO - can we just remove this?
    $routeProvider.onChange(function () {
        self.params = $routeProvider.current.params;
    });
    */
});
