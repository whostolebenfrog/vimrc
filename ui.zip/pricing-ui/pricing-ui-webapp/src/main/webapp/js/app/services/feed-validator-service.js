/*globals angular */

/**
 * Returns a function that will validate the supplied uri and return an object
 * describing the results of that validation to the supplied callback function
 */
var feedsModule = angular.module('feeds', []);
feedsModule.factory('feedValidatorService', function() {

    var validator = {},
        urlStart  = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20xml%20where%20url%20%3D%20'",
        urlEnd    = "'&format=json&diagnostics=true&callback=JSON_CALLBACK";

    validator.validateFeedResponse = function(response) {
        var query = response.query;

        if (query.diagnostics.url['http-status-code'] && query.diagnostics.url['http-status-code'] !== '200') {
            return validator.validationFailed('Feed does not exist');
        } else if ((query.results && query.results.feed) || (query.results && query.results.rss)){
            return validator.validationOK();
        }
        return validator.validationFailed('Not a valid RSS or Atom feed');
    };

    validator.yqlReturnedError = function() {
        return {desc : 'Unable to validate', cssClass : 'label-warning'};
    };

    validator.validationOK = function () {
        return {desc : 'OK', cssClass : 'label-success'};
    };

    validator.validationFailed = function(reason) {
        return {desc : 'Failed - ' + reason, cssClass : 'label-important'};
    };

    validator.buildYQLRequestUri = function(rawUri) {
        return (urlStart + encodeURI(rawUri) + urlEnd);
    };

    return function(uri, callback) {
        this.$xhr('JSON', validator.buildYQLRequestUri(uri), function(code, response) {
            callback(validator.validateFeedResponse(response));
        }, function(code, response) {
            callback(validator.yqlReturnedError());
        });
    };
});
