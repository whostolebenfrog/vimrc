/*globals "angular" "console"*/

function DiscountController($xhr, $route, deliveryBaseUrl ) {
    this.$xhr = $xhr;
    this.$xhr.defaults.headers.put['Content-Type'] = 'application/json';
    this.deliveryBaseUrl = deliveryBaseUrl;
    this.$route = $route;
    
    this.discounts = null;
    this.table = [];
    this.territory = null;
    this.type = null;
    this.gridExsits = null;
    this.headers = [];
    this.srpHeaders = [];
    this.numberOfRows = -1;
    this.editable = false; // false  
    this.info = {};
    this.srpLowerBand = null;
    this.publisherLowerBand = null;
    this.territoryCurrency = null;
    
    this.$watch(function () {
        return $route.current.params;
    }, function (params) {
        this.territory = params.territory;
        this.type = params.type;
    });

    this.getTerritoryDiscounts();
}

DiscountController.prototype = {
    getTerritoryDiscounts : function() {
        var url = this.deliveryBaseUrl + "/griddiscount/"+this.territory+"/"+this.type+"?callback=JSON_CALLBACK" ;
        
        console.log(url);
        this.$xhr("JSON", url, this.getSuccess, this.getError);
    },

    getSuccess : function(code, response) {
        this.discounts = response;
        this.gridExsits = true;
        this.selectCurrencySign();
        this.createHeaders();
        this.createSrpHeaders();
        this.createTable();
    },

    getError : function(code, response) {
        console.log('An error occurred whilst retrieving discounts. Status code was ' + code);
        this.gridExsits = false;
    },
    
    selectCurrencySign : function() {
        
        if(this.territory === 'gb') {
            this.territoryCurrency = '£';
            return;
        }
        if(this.territory === 'ru') {
            this.territoryCurrency = 'руб ';
            return;
        }
        this.territoryCurrency = '€';
    },
    
    territoryChange : function() {
        var hashSearch = this.$location.hashSearch;
        if (this.territory) {
             hashSearch.territory = this.territory;
        } else {
            delete(hashSearch.territory);
        }
        this.$location.updateHash(this.$location.hashPath, hashSearch);
    
    },
    
    typeChange : function() {
        var hashSearch = this.$location.hashSearch;
        if (this.type) {
             hashSearch.type = this.type;
        } else {
            delete(hashSearch.type);
        }
        this.$location.updateHash(this.$location.hashPath, hashSearch);
    
    },
    
    createHeaders : function() {
    
        var i, size, bands;
        
        bands = this.discounts.srpbands[0].publisherDiscountBands;
        size = angular.Object.size(this.discounts.srpbands[0].publisherDiscountBands, true);

        this.headers=[];
        if(size === 1 ) {
            this.headers[0] = {};
            this.headers[0].name = bands[0].lowerLimit + "% +";
            this.headers[0].lowerLimit = bands[0].lowerLimit;
        }else 
            {
                for(i=0; i<size ;i++) {
                    this.headers[i]= {};
                    this.headers[i].lowerLimit = bands[i].lowerLimit;
                    if(bands[i+1]) {
                        this.headers[i].name = bands[i].lowerLimit + "% - " +  (bands[i+1].lowerLimit -1) +"%";
                    }else {
                        this.headers[i].name = bands[i].lowerLimit + "% + ";
                    }
                   
            }
        }
    },

    createSrpHeaders : function() {

        var i, size, bands, lower, name, higer;
       
        size = angular.Object.size(this.discounts.srpbands, true);
        bands = this.discounts.srpbands;
        this.srpHeaders = [];
        if(size === 1 ) {
            this.srpHeaders[0] = this.territoryCurrency + " " + parseFloat(bands[0].lowerLimit).toFixed(2) +" +" ;
        }else {
            for(i=0; i<size ;i++) {
                lower = parseFloat(bands[i].lowerLimit).toFixed(2);
                name = null;
                if(bands[i+1]) {
                    higer = parseFloat(bands[i+1].lowerLimit).toFixed(2)-0.01;
                    name = this.territoryCurrency +  lower + " - "+this.territoryCurrency + higer;
                }else {
                    name = this.territoryCurrency +  lower + " +";
                }
                this.srpHeaders[i] = name;
            }
        }
        this.numberOfRows=-1;
    },
    
    createTable : function() {
        var bands, column, rowSize, rowNumber, row, discount, columnSize, item;
        
        bands = this.discounts.srpbands;
        rowSize = angular.Object.size(bands, true);
        
        for(rowNumber=0; rowNumber<rowSize ; rowNumber++) {
            row = [];
            item = {}; 
            discount = bands[rowNumber].publisherDiscountBands; 
            columnSize = angular.Object.size(discount, true);
        
            item.value = this.srpHeaders[rowNumber];
            row[0] = item;
            for(column = 0; column < columnSize ; column++) {
                item = {};
                item.value = discount[column].retailerDiscount;
                item.icon = true;
                item.editable = true;
                item.name = "r"+rowNumber+"c"+(column+1);	
                row[column+1] = item;
            }
        this.table[rowNumber] = row;
        }
    },
    
    updateGrid : function() {
        this.info = {};
        var url = this.deliveryBaseUrl + "/griddiscount/" + this.territory + "/" + this.type, data = this.discounts ;
        console.log(url);
        
        if(!this.checkBeforeUpdate()) {
            this.info.message = "Discount has to be in range 0 - 100!.";
            this.info.label = "label label-important";
            this.info.update = true;
            return;
        }
        
        this.$xhr('PUT', url, this.discounts, this.updateSuccess, this.updateError);
    },
    
    checkBeforeUpdate : function() {
        
        var rowSize,columnSize,row,column,number;
        
        rowSize = angular.Object.size(this.discounts.srpbands, true);
        columnSize = angular.Object.size(this.discounts.srpbands[0].publisherDiscountBands, true);
        
        for(row=0; row<rowSize; row++) {
            for(column=0; column<columnSize; column++) {
                number = parseFloat(this.discounts.srpbands[row].publisherDiscountBands[column].retailerDiscount).toFixed(2);
                if(number < 0.00 || number>100.00){
                    return false;
                }
            }
        }
        return true;
        
    },
    
    updateSuccess : function(response) {
        this.info.message = "Update successful.";
        this.info.label = "label label-success";
        this.info.update = true;
    },
    
    updateError : function(response) {
        this.info.message = "An error occurred while updating discount grid!!!";
        this.info.label = "label label-important";
        this.info.update = true;
        console.log('An error occurred while updating discount grid. Status code was ' + response.code);
    },
    
    count : function() {
        var size = angular.Object.size(this.discounts.srpbands, true);
        this.numberOfRows = this.numberOfRows + 1;
        if(size === this.numberOfRows) {
            this.numberOfRows=0;
        }
        return this.numberOfRows;
    },
    
    edit : function() {
        if(this.editable) {
            this.editable = false;
        }else 
        {
            this.editable = true;
        }
    },
    
    cancel : function() {
        this.edit();
        this.getTerritoryDiscounts();
        this.info = {};
    },
    
    addSrp : function() {

        var size, row, publisherSize, pubSize,column;
        this.info = {};
        size = angular.Object.size(this.discounts.srpbands, true);
        publisherSize = angular.Object.size(this.discounts.srpbands[0].publisherDiscountBands, true);

        if(this.srpLowerBand ){
            
            for(column=0; column<size; column++){
                
                if(parseFloat(this.discounts.srpbands[column].lowerLimit).toFixed(2) === parseFloat(this.srpLowerBand).toFixed(2)) {
                    this.info.message = "SRP band exsits. Cannot duplicate it!";
                    this.info.label = "label label-important";
                    this.info.srp = true;
                    this.srpLowerBand=null;
                    return;
                }
            }

            if(isNaN(this.srpLowerBand)) {
                    this.info.message = "SRP band has to be a number.";
                    this.info.label = "label label-important";
                    this.srpLowerBand=null;
                    this.info.srp = true;
                    return;
            }
            
            if(parseFloat(this.srpLowerBand) < 0) {
              this.info.message = "SRP band has to be greater or equal than O.";
              this.info.label = "label label-important";
              this.info.srp = true;
              this.srpLowerBand=null;
                    return;
                }

            this.discounts.srpbands[size] = {};
            this.discounts.srpbands[size].publisherDiscountBands = [];
            this.discounts.srpbands[size].lowerLimit = parseFloat(this.srpLowerBand);
            
            for(pubSize=0; pubSize<publisherSize; pubSize++) {
                this.discounts.srpbands[size].publisherDiscountBands[pubSize] = {};
                this.discounts.srpbands[size].publisherDiscountBands[pubSize].lowerLimit = this.discounts.srpbands[0].publisherDiscountBands[pubSize].lowerLimit;
                this.discounts.srpbands[size].publisherDiscountBands[pubSize].retailerDiscount = 0;
            }

            this.discounts.srpbands.sort(function(a,b){
                return parseFloat(a.lowerLimit) - parseFloat(b.lowerLimit);
            });
            this.srpLowerBand=null;
            this.info = {};
            this.createSrpHeaders();
        }
        
    },
    
    addDiscount : function() {
        
        var rowSize, row, columnSize, column;
        this.info = {};
        rowSize = angular.Object.size(this.discounts.srpbands, true);
        columnSize = angular.Object.size(this.discounts.srpbands[0].publisherDiscountBands, true);

        if(this.publisherLowerBand ){

            for(column=0; column<columnSize; column++){
                
                if(this.discounts.srpbands[0].publisherDiscountBands[column].lowerLimit === parseInt(this.publisherLowerBand,10)) {
                    this.info.message = "Publisher discount exsits. Cannot duplicate it!";
                    this.info.label = "label label-important";
                    this.info.publisher = true;
                    this.publisherLowerBand=null;
                    return;
                }
            }
            
            if(isNaN(this.publisherLowerBand)) {
                    this.info.message = "Publisher discount has to be a number.";
                    this.info.label = "label label-important";
                    this.info.publisher = true;
                    this.publisherLowerBand=null;
                    return;
            }
            
            if(parseInt(this.publisherLowerBand,10) < 0) {
                  this.info.message = "Publisher discount has to be greater or equal than O.";
                  this.info.label = "label label-important";
                  this.info.publisher = true;
                  this.publisherLowerBand=null;
                  return;
                }

            for(row=0; row<rowSize; row++){
                
                this.discounts.srpbands[row].publisherDiscountBands[columnSize] = {};
                this.discounts.srpbands[row].publisherDiscountBands[columnSize].lowerLimit = parseFloat(this.publisherLowerBand);
                this.discounts.srpbands[row].publisherDiscountBands[columnSize].retailerDiscount = 0;
                
                this.sortItOut(this.discounts.srpbands[row].publisherDiscountBands);

            }
            this.createHeaders();
            this.publisherLowerBand = null;
            this.info = {};
        }
    },
    
    sortItOut : function(sorting) {
        sorting.sort(function(a,b){
          return parseFloat(a.lowerLimit) - parseFloat(b.lowerLimit);});
    },
    
    removeSrp : function(remove) {
        
        var rowSize, row, columnSize, column;
    
        rowSize = angular.Object.size(this.discounts.srpbands, true);
        
        if(remove===0) {
            return;
        }
        
        for(row=0; row<rowSize; row++) {
        
            if( this.discounts.srpbands[row] && this.discounts.srpbands[row].lowerLimit === remove) {
                angular.Array.remove(this.discounts.srpbands, this.discounts.srpbands[row]);
            }
        }
         
         this.discounts.srpbands.sort(function(a,b){
                return parseFloat(a.lowerLimit) - parseFloat(b.lowerLimit);
            });
         this.createSrpHeaders();
    },
    
    removeDiscount : function(remove) {
        
        var rowSize, row, columnSize, column;
         if(remove===0) {
             return;
        }
        
        rowSize = angular.Object.size(this.discounts.srpbands, true);
        columnSize = angular.Object.size(this.discounts.srpbands[0].publisherDiscountBands, true);
        
        for(row=0; row<rowSize; row++) {
        
            for(column=0; column<columnSize; column++){
                
                if( this.discounts.srpbands[row].publisherDiscountBands[column] && this.discounts.srpbands[row].publisherDiscountBands[column].lowerLimit === remove) {
                    angular.Array.remove(this.discounts.srpbands[row].publisherDiscountBands, this.discounts.srpbands[row].publisherDiscountBands[column]);
                }
            }
            this.sortItOut(this.discounts.srpbands[row].publisherDiscountBands);
        
        }
        this.createHeaders();
    }
};

DiscountController.$inject = [ '$xhr', '$route', 'deliveryBaseUrl'];
