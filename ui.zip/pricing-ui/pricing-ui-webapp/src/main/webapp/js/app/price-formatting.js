function getLocalDecimalSeparator() {
    var num = 1.1;
    return num.toLocaleString().substring(1, 2);
}

var localDecimalSeparator = getLocalDecimalSeparator(); 

String.prototype.toPriceFloat = function() {
    var javascriptNumberString = this.replace(localDecimalSeparator, ".");
    
    return parseFloat(javascriptNumberString);
};

String.prototype.toLocalePrice = function() {
    return this.toPriceFloat().toFixed(2).replace(".", localDecimalSeparator);
};
