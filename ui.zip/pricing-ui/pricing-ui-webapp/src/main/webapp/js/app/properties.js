/*globals "angular" */

// TODO - is it ok to have a pricing moudle - how do we reference these from it?

var pricingModule = angular.module('pricing', []);

pricingModule.factory('searchBaseUrl', function() {
    return '$serviceToolsBaseUrl/search/2.x';
}, { $eager: 'true' });

pricingModule.factory('itemsPerPage', function() {
    return 12;
}, { $eager: 'true' });

pricingModule.factory('deliveryBaseUrl', function() {
    return '$serviceToolsBaseUrl/deliveryengine/1.x';
}, { $eager: 'true' });
