/*globals "console" */

function TaxController($xhr, deliveryBaseUrl) {
    this.$xhr = $xhr;
    this.deliveryBaseUrl = deliveryBaseUrl;
    this.getTerritoryTaxes();
}

TaxController.prototype = {
    getTerritoryTaxes : function() {
        var url = this.deliveryBaseUrl + "/tax?callback=JSON_CALLBACK";
        console.log(url);
        this.$xhr("JSON", url, this.getSuccess, this.getError);
    },

    getSuccess : function(code, response) {
        this.taxes = response;
    },

    getError : function(code, response) {
        console.log('An error occurred whilst retrieving taxes. Status code was ' + code);
    }
};

TaxController.$inject = [ '$xhr', 'deliveryBaseUrl' ];
