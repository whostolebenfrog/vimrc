/*global module,test,FeedsController,equal,notEqual,angular*/

module("feeds-controller-test", {
    
	setup : function () {
        this.scope = angular.scope();
        this.$xhrMock = this.scope.$service('$browser').xhr;
        this.originalItems ={
                "items": [
                          {
                                  "name": "category1",
                                  "feeds": [
                                  {
                                          "uri": "url1",
                                          "downloadAllowed": true
                                  }
                                  ]
                          },
                          {
                                  "name": "category2",
                                  "feeds": [
                                  {
                                          "uri": "url2",
                                          "downloadAllowed": true
                                  }
                                  ]
                          }
                          ]
                  } ;
    }
	
});

test("can create controller", function () {
	// when
	var controller = this.scope.$new(FeedsController);
	// then
	notEqual(controller, null);	
});

test("categories found and stored", function () {
	// given
	this.$xhrMock.expectGET("/proxy/eapi/1.x/gb/feeds/private").respond(this.originalItems);	
	var controller = this.scope.$new(FeedsController);
	controller.territory="gb";	
	// when
	controller.getCategories();
	this.$xhrMock.flush();
    // then
	equal(controller.categories,this.originalItems.items);
});

test("save categories shows success info message", function () {
    //Given
    this.$xhrMock.expectGET("/proxy/eapi/1.x/gb/feeds/private").respond(this.originalItems);
    this.$xhrMock.expectPUT("/proxy/eapi/1.x/gb/feeds/private",this.originalItems).respond(201);
    
    var controller = this.scope.$new(FeedsController);
    controller.territory="gb";  
    controller.getCategories();
    this.$xhrMock.flush();  
    
    equal(controller.showInfoMessage, false);

    //When
    controller.validateFields();
    this.$xhrMock.flush();
    
    
    //Then
    equal(controller.showInfoMessage, true);
});

test("404 on getFeed is handled", function () {
    //Given
    this.$xhrMock.expectGET("/proxy/eapi/1.x/gb/feeds/private").respond(404);
    
    var controller = this.scope.$new(FeedsController);
    controller.territory="gb";
    
    //When
    controller.getCategories();
    this.$xhrMock.flush();
    
    //Then
    notEqual(controller.categories, null); 
    equal(controller.categories.length, 0);
});

test("Incomplete form results in validation error", function() {
    //Given
    var controller = this.scope.$new(FeedsController),
        requestUriMock, 
        feedsUriServiceIsCalled = false;
    
    requestUriMock = {
            feedsUri : function(territory) {
                feedsUriServiceIsCalled = true;
            }
    };
    
    controller.territory="gb";
    controller.requestUriCreator = requestUriMock;
    
    //When
    controller.addNewCategory();
    controller.validateFields();
    
    //Then
    equal(feedsUriServiceIsCalled, false);
    equal(controller.showInfoMessage, true);
    equal(controller.infoMessageClass, 'alert alert-error');
});

test("Can add category and feed", function() {
    // given
    var controller = this.scope.$new(FeedsController),
        requestUriMock, 
        feedsUriServiceIsCalled = false,
        feed;

    this.$xhrMock.expectGET("/proxy/eapi/1.x/gb/feeds/private").respond({"items": {}});
    controller.territory="gb";
    
    // when
    controller.addNewCategory();
    controller.addNewFeed(0);
    controller.categories[0].name = "Category Name";

    feed = controller.categories[0].feeds[0];
    feed.name = "Feed name";
    feed.uri = "http://someuri.com/";

    // then
    this.$xhrMock.expectPUT("/proxy/eapi/1.x/gb/feeds/private", {"items": controller.categories}).respond(201);
    controller.validateFields();
    this.$xhrMock.flush();
});

test("No feed name results in validation error", function() {
    // given
    var controller = this.scope.$new(FeedsController),
        requestUriMock, 
        feedsUriServiceIsCalled = false;
    
    requestUriMock = {
        feedsUri : function(territory) {
            feedsUriServiceIsCalled = true;
        }
    };
    
    controller.territory="gb";
    controller.requestUriCreator = requestUriMock;
    
    // when
    controller.addNewCategory();
    controller.addNewFeed(0);
    controller.categories[0].feeds[0].uri = "http://someuri.com/";
    controller.validateFields();
    
    // then
    equal(feedsUriServiceIsCalled, false);
    equal(controller.showInfoMessage, true);
    equal(controller.infoMessageClass, 'alert alert-error');
});

test("first category can be moved down", function () {
	// given
	var controller = this.scope.$new(FeedsController),
	firstItem;
	controller.categories=this.originalItems.items;
	firstItem= controller.categories[0];
	// when
	controller.moveDownCategory(0);
	// then
	equal(firstItem,controller.categories[1]);
	
});

test("even first category can be moved up", function () {
	// given
	var controller = this.scope.$new(FeedsController),
	firstItem;
	controller.categories=this.originalItems.items;
	firstItem= controller.categories[0];
	// when
	controller.moveUpCategory(0);
	// then
	equal(firstItem,controller.categories[1]);
	
});

test("last category can be moved up", function () {
	// given
	var controller = this.scope.$new(FeedsController),
	lastItem;
	controller.categories=this.originalItems.items;
	lastItem= controller.categories[1];
	// when
	controller.moveUpCategory(1);
	// then
	equal(lastItem,controller.categories[0]);
	
});

test("even last category can be moved down", function () {
	// given
	var controller = this.scope.$new(FeedsController),
	lastItem;
	controller.categories=this.originalItems.items;
	lastItem= controller.categories[1];
	// when
	controller.moveDownCategory(1);
	// then
	equal(lastItem,controller.categories[0]);
	
});

test("category can be deleted", function () {
	// given
	var controller = this.scope.$new(FeedsController);
	controller.categories=this.originalItems.items;
	// when
	controller.deleteCategory(0);
	// then
	equal(angular.Array.count(controller.categories),1);
	equal(controller.categories[0].name,"category2");
	
});

test("Validate single feed attempts to validate the feed", function() {
    // given
    var controller = this.scope.$new(FeedsController),
        feedValidatorServiceMock, 
        feedValidatorServiceMockIsCalled = false,
        validationObject = {};
    
    feedValidatorServiceMock = function(uri, callback) {
        feedValidatorServiceMockIsCalled = true;
        validationObject = {validated : uri};
        callback(validationObject);
    };

    controller.feedValidatorService = feedValidatorServiceMock;
	controller.categories = this.originalItems.items;

	// when
    controller.validateSingleFeed(0, 0);

    // then
    equal(controller.numFeeds, 1);
    equal(feedValidatorServiceMockIsCalled, true);
    equal(controller.validationState[controller.getMetaId(0,0)], validationObject);
});


test("Validate all feeds attempts to validate the feed", function() {
    // given
    var controller = this.scope.$new(FeedsController),
        feedValidatorServiceMock, 
        feedValidatorServiceMockIsCalled = false;
    
    feedValidatorServiceMock = function(uri, callback) {
        feedValidatorServiceMockIsCalled = true;
        callback({});
    };

    controller.feedValidatorService = feedValidatorServiceMock;
	controller.categories = this.originalItems.items;

	// when
    controller.validateAllFeeds();

    // then
    equal(controller.numFeeds, 2);
    equal(feedValidatorServiceMockIsCalled, true);
});

test("Validate all fields is hidden when number of feeds is empty", function() {
    // given
	var controller = this.scope.$new(FeedsController),
        validateAllState; 

    controller.numFeeds = 0;
    controller.finishedFeeds = 0;

    // when
    validateAllState = controller.validateAllFeedsState();

    // then
    equal(validateAllState, 'hide');
});

test("Validate all fields is shown when the number of feeds is greater than the finished number of feeds", function() {
    // given
	var controller = this.scope.$new(FeedsController),
        validateAllState; 

    controller.numFeeds = 2;
    controller.finishedFeeds = 1;

    // when
    validateAllState = controller.validateAllFeedsState();

    // then
    equal(validateAllState, 'show');
});

test("Validate all fields progress returns 100 when all feeds completed", function() {
    // given
	var controller = this.scope.$new(FeedsController),
        percentageComplete; 

    controller.numFeeds = 2;
    controller.finishedFeeds = 2;

    // when
    percentageComplete = controller.validateAllFeedsProgress();

    // then
    equal(percentageComplete, 100);
});

test("Validate all fields progress returns 33.3' when one third of feeds completed", function() {
    // given
	var controller = this.scope.$new(FeedsController),
        percentageComplete; 

    controller.numFeeds = 3;
    controller.finishedFeeds = 1;

    // when
    percentageComplete = controller.validateAllFeedsProgress();

    // then
    equal(percentageComplete, (1/3 * 100));
});
