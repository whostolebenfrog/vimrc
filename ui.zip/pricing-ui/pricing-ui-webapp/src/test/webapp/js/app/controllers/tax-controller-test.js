/*global module,test,TaxController,equal,notEqual,angular*/

module("tax-controller-test", {
    setup : function () {
        this.scope = angular.scope();
        this.$xhrMock = this.scope.$service('$browser').xhr;
        
        angular.service('deliveryBaseUrl', function () {
            return "";
        });
    }
});

test("can create controller", function () {
    this.$xhrMock.expectJSON("/tax?callback=JSON_CALLBACK").respond("");
    
    var controller = this.scope.$new(TaxController);
    this.$xhrMock.flush();    
    
    notEqual(controller, null);
});

test("taxes are stored correctly after retrieval", function () {
    var expectedResponse = [{ territory: 'gb', value: 12.34 }, { territory: 'de', value: 56.78 }],
        controller = null;
    
    this.$xhrMock.expectJSON("/tax?callback=JSON_CALLBACK").respond(expectedResponse);
    
    controller = this.scope.$new(TaxController);
    this.$xhrMock.flush();
    
    equal(controller.taxes, expectedResponse);
});

test("taxes are empty if an error occurs retrieving them", function () {
    this.$xhrMock.expectJSON("/tax?callback=JSON_CALLBACK").respond(500);
    
    var controller = this.scope.$new(TaxController);
    this.$xhrMock.flush();
    
    equal(controller.taxes, null);
});
