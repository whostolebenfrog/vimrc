/*global module,test,SearchController,angular,notEqual,equal,TestRoute*/

module("search-controller-test", {
    setup : function () {
        this.scope = angular.scope();
        this.$xhrMock = this.scope.$service('$browser').xhr;
        this.$route = this.scope.$service("$route");

        new TestRoute().setAsCurrent(this.scope);
        
        angular.service('searchBaseUrl', function () {
            return "";
        });
        angular.service('deliveryBaseUrl', function () {
            return "";
        });
        angular.service('itemsPerPage', function () {
            return 10;
        });
    }
});

test("when search results won't fit on an exact number of pages, max page is set correctly", function () {
    var territory = "gb",
        itemsPerPage = 3,
        searchResults = { items: [], paging: { total: 7 }},
        controller = this.scope.$new(SearchController);
    
    this.$xhrMock.expectJSON("/gb/books?q=whatever&callback=JSON_CALLBACK&itemsperpage=" + itemsPerPage + "&startindex=0&f-type=book").respond(searchResults);
    this.$xhrMock.expectJSON("/discount/" + territory + "?callback=JSON_CALLBACK").respond({});    
    this.$xhrMock.expectJSON("/tax/" + territory + "?callback=JSON_CALLBACK").respond({});    
    
    controller.territory = territory;
    controller.itemsPerPage = itemsPerPage;
    controller.searchTerm = "whatever";

    controller.search();

    this.$xhrMock.flush();
    
    equal(controller.maxPage, 3);
});

test("when search results fit on an exact number of pages, max page is set correctly", function () {
    var territory = "gb",
        itemsPerPage = 3,
        searchResults = { items: [], paging: { total: 6 }},
        controller = this.scope.$new(SearchController);
    
    this.$xhrMock.expectJSON("/gb/books?q=whatever&callback=JSON_CALLBACK&itemsperpage=" + itemsPerPage + "&startindex=0&f-type=book").respond(searchResults);
    this.$xhrMock.expectJSON("/discount/" + territory + "?callback=JSON_CALLBACK").respond({});    
    this.$xhrMock.expectJSON("/tax/" + territory + "?callback=JSON_CALLBACK").respond({});    
    
    controller.territory = territory;
    controller.itemsPerPage = itemsPerPage;
    controller.searchTerm = "whatever";

    controller.search();
    
    this.$xhrMock.flush();
    
    equal(controller.maxPage, 2);
});
