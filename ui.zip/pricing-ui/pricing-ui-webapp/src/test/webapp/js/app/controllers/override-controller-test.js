/*global module,test,OverrideController,angular,notEqual,equal,TestRoute*/

module("override-controller-test", {
    setup : function () {
        this.scope = angular.scope();
        this.$xhrMock = this.scope.$service('$browser').xhr;
        this.$route = this.scope.$service("$route");
        
        new TestRoute().setAsCurrent(this.scope);
        
        angular.service('searchBaseUrl', function () {
            return "";
        });
        angular.service('deliveryBaseUrl', function () {
            return "";
        });
    }
});

test("can create controller", function () {
    
    var controller = this.scope.$new(OverrideController);
    
    notEqual(controller, null);
});

test("tax is retrieved when territory is changed", function () {
    
    var territory = "gb",
        expectedTax = 1,
        taxResponse = { territory: territory, value: expectedTax },
        controller = this.scope.$new(OverrideController);
    
    equal(controller.tax, null);
    
    this.$xhrMock.expectJSON("/tax/" + territory + "?callback=JSON_CALLBACK").respond(taxResponse);    
    
    controller.territory = territory;
    
    new TestRoute().withParam("territory", territory).withParam("entityId", 1).setAsCurrent(this.scope);    
    this.$xhrMock.flush();    
    
    equal(controller.tax, expectedTax);    
});

test("override price buttons are disabled if price override is empty", function () {
    var controller = this.scope.$new(OverrideController);
    
    controller.priceOverride = null;
    this.scope.$eval();
    
    equal(controller.overridePriceButtonDisabled, true);
});

test("override price buttons are disabled if price override is non-numeric", function () {
    var controller = this.scope.$new(OverrideController);
    
    controller.priceOverride = "bollox";
    this.scope.$eval();
    
    equal(controller.overridePriceButtonDisabled, true);
});

test("override price buttons are disabled if price override is numeric", function () {
    var controller = this.scope.$new(OverrideController);
    
    controller.priceOverride = "123.45";
    
    this.scope.$eval();
    
    equal(controller.overridePriceButtonDisabled, false);
});

test("override price input is enabled if business mode of selected entity is 'b2c'", function () {
    var bookId = 1,
        territory = "gb",
        controller = this.scope.$new(OverrideController);
  
    this.$xhrMock.expectJSON("/override/" + territory + "/" + bookId + "?callback=JSON_CALLBACK").respond({});    
    this.$xhrMock.expectJSON("/discount/" + territory + "?callback=JSON_CALLBACK").respond({});    
    this.$xhrMock.expectJSON("/tax/" + territory + "?callback=JSON_CALLBACK").respond({});    

    this.scope.$eval();
    
    controller.territory = territory;
    controller.selectedEntity = { bookid: bookId, wholesaleprices: { permanentdownload: { businessmode: "b2c" }}};

    this.scope.$eval();
    
    equal(controller.overridePriceInputDisabled, false);
});

test("override price input is disabled if business mode of selected entity is not 'b2c'", function () {
    var bookId = 1,
        territory = "gb",
        controller = this.scope.$new(OverrideController);
  
    this.$xhrMock.expectJSON("/override/" + territory + "/" + bookId + "?callback=JSON_CALLBACK").respond({});    
    this.$xhrMock.expectJSON("/discount/" + territory + "?callback=JSON_CALLBACK").respond({});    
    this.$xhrMock.expectJSON("/tax/" + territory + "?callback=JSON_CALLBACK").respond({});    
    
    controller.territory = territory;
    controller.selectedEntity = { bookid: bookId, wholesaleprices: { permanentdownload: { businessmode: "agency" }}};
    this.scope.$eval();
    
    equal(controller.overridePriceInputDisabled, true);
});