/*global module,test,DiscountController,equal,notEqual,angular,TestRoute*/

module("discount-controller-test", {
    setup : function () {
        this.scope = angular.scope();
        this.$xhrMock = this.scope.$service("$browser").xhr;
        this.$route = this.scope.$service("$route");
        this.dummyDiscountUrl = "/griddiscount/gb/sometype?callback=JSON_CALLBACK"; 

        new TestRoute().withParam("territory", "gb").withParam("type", "sometype").setAsCurrent(this.scope);
        
        angular.service('deliveryBaseUrl', function () {
            return "";
        });
    }
});

test("can create controller", function () {
    this.$xhrMock.expectJSON(this.dummyDiscountUrl).respond("");
    
    var controller = this.scope.$new(DiscountController);
    this.$xhrMock.flush();    
    
    notEqual(controller, null);
});

test("discounts are stored correctly after retrieval", function () {
    var expectedResponse = [{ territory: 'gb', value: 12.34 }, { territory: 'de', value: 56.78 }],
        controller = null;
    
    this.$xhrMock.expectJSON(this.dummyDiscountUrl).respond(expectedResponse);
    
    controller = this.scope.$new(DiscountController);
    this.$xhrMock.flush();
    
    equal(controller.discounts, expectedResponse);
});

test("discounts are empty if an error occurs retrieving them", function () {
    
    this.$xhrMock.expectJSON(this.dummyDiscountUrl).respond(500);
    
    var controller = this.scope.$new(DiscountController);
    this.$xhrMock.flush();
    
    equal(controller.discounts, null);
});
