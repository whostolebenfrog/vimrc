package com.nokia.ent.tooling.reading.pricing.at;

import com.github.restdriver.clientdriver.ClientDriverRule;
import com.nokia.ent.tooling.reading.pricing.at.drivers.pages.FeedsPageDriver;
import com.nokia.ent.tooling.reading.pricing.at.drivers.services.EapiQueryDriver;
import org.hamcrest.Matchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static com.nokia.ent.tooling.reading.pricing.at.drivers.SeleniumTestDriver.*;
import static junit.framework.Assert.*;
import static org.junit.Assert.assertThat;

public class FeedsSeleniumTest {

    private static final int FIRST_CATEGORY_INDEX = 0;
    private static final int SECOND_CATEGORY_INDEX = 1;
    private static final int TOTAL_NUMBER_OF_CATEGORIES = 2;
    private static final int TOTAL_NUMBER_OF_FEEDS = 4;

    private static final String SECOND_CATEGORY_NAME = "Technology";
    private static final String FIRST_CATEGORY_NAME = "Fashion";
    private static final String TERRITORY = "gb";

    @Rule
    public ClientDriverRule clientDriver = new ClientDriverRule(getRestDriverPort());

    private FeedsPageDriver feedsPageDriver;

    @Before
    public void setupClientDriver() {
        feedsPageDriver = new FeedsPageDriver();
    }

    @After
    public void shutdownClientDriver() {
        feedsPageDriver.teardown();
    }

    @Test
    public void showsCategoriesForTerritiory() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);

        // When
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);

        // Then
        assertEquals(TOTAL_NUMBER_OF_CATEGORIES, feedsPageDriver.countCategories());
    }

    @Test
    public void categoryCanBeMovedUpAndResultCanBeSaved() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);
        EapiQueryDriver.expectPutFeeds(clientDriver, TERRITORY, SECOND_CATEGORY_NAME, FIRST_CATEGORY_NAME);

        // When
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        feedsPageDriver.moveUpCategory(SECOND_CATEGORY_INDEX);
        feedsPageDriver.clickSave();

        // Then
        assertTrue(feedsPageDriver.infoMessageIsShown());
    }

    @Test
    public void categoryCanBeMovedDown() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);

        // When
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        assertEquals(FIRST_CATEGORY_NAME, feedsPageDriver.getCategoryName(FIRST_CATEGORY_INDEX));
        feedsPageDriver.moveDownCategory(FIRST_CATEGORY_INDEX);

        // Then
        assertEquals(FIRST_CATEGORY_NAME, feedsPageDriver.getCategoryName(SECOND_CATEGORY_INDEX));
    }

    @Test
    public void categoryCanBeDeleted() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        assertEquals(TOTAL_NUMBER_OF_CATEGORIES, feedsPageDriver.countCategories());

        // When
        feedsPageDriver.clickDeleteCategory();

        // Then
        assertEquals(TOTAL_NUMBER_OF_CATEGORIES - 1, feedsPageDriver.countCategories());
    }

    @Test
    public void feedCanBeDeleted() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        assertEquals(TOTAL_NUMBER_OF_FEEDS, feedsPageDriver.countFeeds());

        // When
        feedsPageDriver.clickDeleteFeed();

        // Then
        assertEquals(TOTAL_NUMBER_OF_FEEDS - 1, feedsPageDriver.countFeeds());
    }

    @Test
    public void categoryCanBeAdded() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        assertEquals(TOTAL_NUMBER_OF_CATEGORIES, feedsPageDriver.countCategories());

        // When
        feedsPageDriver.clickAddCategory();

        // Then
        assertEquals(TOTAL_NUMBER_OF_CATEGORIES + 1, feedsPageDriver.countCategories());
    }

    @Test
    public void feedCanBeAdded() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        assertEquals(TOTAL_NUMBER_OF_FEEDS, feedsPageDriver.countFeeds());

        // When
        feedsPageDriver.clickAddFeed();

        // Then
        assertEquals(TOTAL_NUMBER_OF_FEEDS + 1, feedsPageDriver.countFeeds());
    }

    @Test
    public void changesCanBeCanceled() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        feedsPageDriver.setCategoryName(FIRST_CATEGORY_INDEX, "name update");

        // When
        feedsPageDriver.clickCancel();

        // Then
        assertEquals(FIRST_CATEGORY_NAME, feedsPageDriver.getCategoryName(FIRST_CATEGORY_INDEX));
    }

    @Test
    public void feedWithoutNameDoesNotValidate() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        assertEquals(TOTAL_NUMBER_OF_FEEDS, feedsPageDriver.countFeeds());

        // When
        feedsPageDriver.clickAddFeed();
        feedsPageDriver.setFeedUrlValue(0, 2, "http://example.com/");
        feedsPageDriver.clickSave();

        // Then
        assertEquals(TOTAL_NUMBER_OF_FEEDS + 1, feedsPageDriver.countFeeds());
        assertTrue(feedsPageDriver.infoMessageIsShown());
    }

    @Test
    public void feedCanBeValidated() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);

        // When
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        feedsPageDriver.clickValidateFeed(0, 0);
        String labelValue = feedsPageDriver.getValidationLabelValue(0, 0);

        // Then
        assertThat(labelValue, Matchers.is(Matchers.equalTo("OK")));
    }

    @Test
    public void validateAllFeeds() {
        // Given
        EapiQueryDriver.expectGetFeeds(clientDriver, TERRITORY);

        // When
        feedsPageDriver.loadFeedspage();
        feedsPageDriver.setAndClickTerritory(TERRITORY);
        feedsPageDriver.clickValidateAll();

        // Then
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                String labelValue = feedsPageDriver.getValidationLabelValue(i, j);
                assertThat(labelValue, Matchers.is(Matchers.equalTo("OK")));
            }
        }
    }

}
