package com.nokia.ent.tooling.reading.pricing.at.drivers.pages;

import com.nokia.ent.tooling.reading.pricing.at.drivers.SeleniumTestDriver;
import org.openqa.selenium.By;

public class FeedsPageDriver extends SeleniumTestDriver {

    private class ElementIds {
        private String select_territory = "territory";
        private String button_newCategory = "newCategory";
        private String button_saveChanges = "saveChanges";
        private String button_cancelChanges = "cancelChanges";
        private String button_newFeed = "newFeed";
        private String button_btnDeleteUrl = "btnDeleteUrl";
        private String input_txtCategory_prefix = "txtCategory-";
        private String button_btnDeleteCategory = "btnDeleteCategory";
        private String button_btnMoveDownCategory_prefix = "btnMoveDownCategory-";
        private String button_btnMoveUpCategory_prefix = "btnMoveUpCategory-";
        private String section_infoMessage = "infoMessage";
        private String validate_button = "btnValidateUrl-%s-%s";
        private String validation_label = "validation-label-%s-%s";
        private String validate_all_button = "validateAll";
        private String feed_url_input_text = "txtUrl-%s-%s";
        private String feed_name_input_text = "feed-name-%s-%s";
    }

    private static final int SLEEP_TIME = 200;
    private static final int LONG_SLEEP = 5000;

    private ElementIds ids = new ElementIds();

    public void loadFeedspage() {
        loadPage("#/feeds");
    }

    public int countCategories() {
        return driver.findElements(By.xpath("//div[substring(@id,1,9)='category-']")).size();
    }

    public int countFeeds() {
        return driver.findElements(By.xpath("//input[substring(@id,1,7)='txtUrl-']")).size();
    }

    public void setAndClickTerritory(String territory) {
        setSelectValue(ids.select_territory, territory);
        clickElement(ids.select_territory);
        sleepQuietly(SLEEP_TIME);
    }

    public void moveUpCategory(int categoryId) {
        clickButton(this.ids.button_btnMoveUpCategory_prefix + categoryId);
        sleepQuietly(SLEEP_TIME);
    }

    public void moveDownCategory(int categoryId) {
        clickButton(this.ids.button_btnMoveDownCategory_prefix + categoryId);
        sleepQuietly(SLEEP_TIME);
    }

    public void clickSave() {
        clickButton(this.ids.button_saveChanges);
        sleepQuietly(SLEEP_TIME);
    }

    public boolean infoMessageIsShown() {
        return elementIsDisplayed(this.ids.section_infoMessage);
    }

    public void clickDeleteCategory() {
        clickButton(this.ids.button_btnDeleteCategory);
        sleepQuietly(SLEEP_TIME);
    }

    public void clickDeleteFeed() {
        clickButton(this.ids.button_btnDeleteUrl);
        sleepQuietly(SLEEP_TIME);
    }

    public void clickAddFeed() {
        clickButton(this.ids.button_newFeed);
        sleepQuietly(SLEEP_TIME);
    }

    public void clickAddCategory() {
        clickButton(this.ids.button_newCategory);
        sleepQuietly(SLEEP_TIME);
    }

    public void clickCancel() {
        clickButton(this.ids.button_cancelChanges);
        sleepQuietly(SLEEP_TIME);
    }

    public void setCategoryName(int categoryId, String name) {
        setElementValue(ids.input_txtCategory_prefix + categoryId, name);
    }

    public String getCategoryName(int categoryId) {
        return getElementValue(ids.input_txtCategory_prefix + categoryId);
    }

    public void clickValidateFeed(int categoryId, int feedId) {
        clickButton(String.format(ids.validate_button, categoryId, feedId));
        sleepQuietly(LONG_SLEEP);
    }

    public String getValidationLabelValue(int categoryId, int feedId) {
        return getElementText(String.format(ids.validation_label, categoryId, feedId));
    }

    public void clickValidateAll() {
        clickButton(String.format(ids.validate_all_button));
        sleepQuietly(LONG_SLEEP);
    }
    
    public void setFeedUrlValue(int categoryId, int feedId, String value) {
        setElementValue(String.format(ids.feed_url_input_text, categoryId ,feedId), value);
    }

    public void setFeedNameValue(int categoryId, int feedId, String value) {
        setElementValue(String.format(ids.feed_name_input_text, categoryId ,feedId), value);
    }
}
