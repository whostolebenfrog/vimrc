package com.nokia.ent.tooling.reading.pricing.mock;

import com.github.restdriver.clientdriver.ClientDriverRequest;
import com.github.restdriver.clientdriver.ClientDriverRule;
import org.apache.commons.io.IOUtils;
import org.junit.Rule;
import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import static com.github.restdriver.clientdriver.RestClientDriver.*;

/**
 * Run this in order to click around the UI and facilitate JS/HTML/CSS
 * development.
 * 
 * IntelliJ users, take note! Set an environment variable
 * json_location_prefix=ContentOps/ in the Run configuration.
 * <p>
 * Or replace ContentOps with the name of the module (e.g.
 * pricing-ui-webapp/). Basically in Intellij it needs the name
 * of the module that contains the resources appended.
 */
public class MockResponses {

    private static final String feedsUriTemplate = "/proxy/eapi/1.x/%s/feeds/private";

    /**
     * If you are using IntelliJ, see class comment above.
     */
    private static String intelliJPathPrefix = "";

    static {

        String jsonLocationPrefix = System.getenv("json_location_prefix");
        if (null != jsonLocationPrefix) {
            intelliJPathPrefix = jsonLocationPrefix;
        }
    }

    @Rule
    public ClientDriverRule clientDriver = new ClientDriverRule(getRestDriverPort());

    /**
     * Run this alongside the application itself, for clicking around the UI. It
     * will provide canned responses to all API calls made to backend services.
     * 
     * @throws IOException
     */
    @Test
    public void respondWithMockResponses() throws IOException {

        acceptFeedsGetRequests("gb", "ru");
        notFoundFeeds("fi", "fr", "de", "es");
        acceptFeedsPutRequest("fi");

        System.in.read();
    }

    private void notFoundFeeds(String... territories) {
        for (String territory : territories) {
            clientDriver.addExpectation(onRequestTo(String.format(feedsUriTemplate, territory))
                    .withMethod(ClientDriverRequest.Method.GET), giveEmptyResponse().withStatus(404)).anyTimes();
        }

    }

    private void acceptFeedsGetRequests(String... territories) throws IOException {
        for (String territory : territories) {
            clientDriver.addExpectation(onRequestTo(String.format(feedsUriTemplate, territory))
                    .withMethod(ClientDriverRequest.Method.GET), giveResponse(IOUtils.toString(new FileInputStream(new File(intelliJPathPrefix + "src/test/resources/mock-api/get-feeds.json"))))).anyTimes();

        }
    }

    private void acceptFeedsPutRequest(String... territories) {
        for (String territory : territories) {
            clientDriver.addExpectation(onRequestTo(String.format(feedsUriTemplate, territory))
                    .withMethod(ClientDriverRequest.Method.PUT), giveEmptyResponse().withStatus(201)).anyTimes();

        }
    }

    public static int getRestDriverPort() {
        return Integer.parseInt(System.getProperty("restdriver.port", "48080"));
    }
}
