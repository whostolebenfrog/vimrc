package com.nokia.ent.tooling.reading.pricing.at.drivers;

public class SeleniumVerificationException extends RuntimeException {
	
	private static final long serialVersionUID = -4491160425283045630L;

	public SeleniumVerificationException(String verificationErrorString) {
        super(verificationErrorString);
    }
    
}
