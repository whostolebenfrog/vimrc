package com.nokia.ent.tooling.reading.pricing.at;

import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nokia.ent.tooling.reading.pricing.at.drivers.pages.QunitDriver;

// This is an example of a selenium test in Java
// It loads the js unit test page and asserts no failures

public class QunitSeleniumTest {

    private QunitDriver driver;

    @Before
    public void createDriver() {
        driver = new QunitDriver();
    }

    @Test
    public void testQunitResults() {
        driver.waitForTestsToFinish();
        assertThat(driver.getTestFailureCount(), is(0));
    }

    @After
    public void stopDriver() {
        driver.teardown();
    }

}
