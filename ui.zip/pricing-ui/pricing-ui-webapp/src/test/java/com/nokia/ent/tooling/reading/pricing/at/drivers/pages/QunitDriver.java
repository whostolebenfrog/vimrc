package com.nokia.ent.tooling.reading.pricing.at.drivers.pages;

import static org.hamcrest.Matchers.*;

import org.openqa.selenium.By;

import com.nokia.ent.tooling.reading.pricing.at.drivers.SeleniumTestDriver;

public class QunitDriver extends SeleniumTestDriver {

    public QunitDriver() {
        super();
        loadPage("/unittests.html");
    }

    public void waitForTestsToFinish() {
        waitForElementMatch("qunit-testresult", containsString("Tests completed"));
    }

    public Integer getTestFailureCount() {
        return Integer.valueOf(driver.findElement(By.xpath("//span[contains(@class, 'failed')]")).getText());
    }

}
