package com.nokia.ent.tooling.reading.pricing.at.drivers;

import org.hamcrest.Matcher;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public abstract class SeleniumTestDriver {

    protected final WebDriver driver;
    private final String baseUrl;
    private final StringBuffer verificationErrors = new StringBuffer();

    public SeleniumTestDriver() {
        driver = new FirefoxDriver();
        baseUrl = "http://localhost:" + getCopsPort();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    public SeleniumTestDriver loadPage(String page) {
        driver.get(baseUrl + page);
        return this;
    }

    public SeleniumTestDriver setElementValue(String elemId, String value) {
        driver.findElement(By.id(elemId)).clear();
        driver.findElement(By.id(elemId)).sendKeys(value);
        return this;
    }

    public SeleniumTestDriver clickButton(String buttonId) {
        driver.findElement(By.id(buttonId)).click();
        return this;
    }

    public String getElementText(String elemId) {
        
        WebElement element = driver.findElement(By.id(elemId));
        String text = element.getText();
        return text;
    }

    public String getElementValue(String elemId) {

        WebElement element = driver.findElement(By.id(elemId));
        String text = element.getAttribute("value");
        return text;
    }

    public void waitForElementMatch(String elemId, Matcher<String> matcher) {

        int retryCount = 20;
        int retryPeriodMs = 500;

        String actualValue = null;

        for (int i = 0; i < retryCount; i++) {
            actualValue = getElementText(elemId);
            if (matcher.matches(actualValue)) {
                return;
            }
            sleepQuietly(retryPeriodMs);
        }
        throw new SeleniumVerificationException("Timeout: Waiting for " + matcher + " in element '" + elemId + "'.  Last value checked was: '" + actualValue + "'");
    }

    public boolean elementIsDisplayed(String elementId) {

        int retryCount = 20;
        int retryPeriodMs = 500;

        WebElement element = driver.findElement(By.id(elementId));

        for (int i = 0; i < retryCount; i++) {

            if (element.isDisplayed()) {
                return true;
            }
            sleepQuietly(retryPeriodMs);
        }
        return false;
    }

    public boolean elementIsHidden(String elementId) {

        int retryCount = 20;
        int retryPeriodMs = 500;

        WebElement element = driver.findElement(By.id(elementId));

        for (int i = 0; i < retryCount; i++) {

            if (!element.isDisplayed()) {
                return true;
            }
            sleepQuietly(retryPeriodMs);
        }
        return false;
    }

    public void waitForElementDisplayed(String elemId) {

        if(!elementIsDisplayed(elemId)) {

            throw new SeleniumVerificationException("Timeout: Waiting for element '" + elemId + "' to be displayed.'");
        }
    }

    public void waitForElementHidden(String elemId) {

        if(!elementIsHidden(elemId)) {
            throw new SeleniumVerificationException("Timeout: Waiting for element '" + elemId + "' to be hidden.'");
        }
    }

    /**
        This was initially private but have made this protected now for the page drivers to access.
        AngularJS evalulates the view 25ms after a model property has been updated so some tests
        fail because Selenium tests for an effect too soon.
     */
    protected void sleepQuietly(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void teardown() {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            throw new SeleniumVerificationException(verificationErrorString);
        }
    }

    public static String getCopsPort() {
        return System.getProperty("cops.port", "8080");
    }

    public static int getRestDriverPort() {
        return Integer.parseInt(System.getProperty("restdriver.port", "48080"));
    }
    
    public void setSelectValue(String elemId, String value) {
        WebElement element = this.driver.findElement(By.id(elemId));
        element.findElements(By.xpath("option[@value=\"" + value + "\"]")).get(0).click();
    }

    /**
     * Gets a list of Strings representing the value field of any selected option elements
     * that are children of the select element with the selectId id
     * @param selectId The id of the select element that contains the option elements to inspect
     * @return A list of the selected option values
     */
    public List<String> getSelectedOptionValues(String selectId) {

        // the values of the selected option elements
        List<String> found = new ArrayList<String>();

        // find the select element
        WebElement select = driver.findElement(By.id((selectId)));

        // add the selected option element values to the list
        for(WebElement option : select.findElements(By.tagName("option")))             {

            if(option.isSelected()) {
                found.add(option.getText());
            }
        }
        return found;
    }

    /**
     * Selects any options in a parent select element that have the values as defined in the selectedOptionsValues
     * argument
     * @param selectId The id of the select element to target
     * @param selectedOptionsValues The list of Strings representing the value of any option elements that are to be selected
     */
    public void setSelectedOptionValues(String selectId, List<String> selectedOptionsValues) {

        WebElement select = driver.findElement(By.id(selectId));

        Select multipleSelect = new Select(select);
        multipleSelect.deselectAll();

        for(String elementToSelect : selectedOptionsValues) {
            multipleSelect.selectByValue(elementToSelect);
        }
    }

    /**
     * Gets the text from a table cell
     * @param tableId The id of the table to inspect
     * @param rowNumber The zero indexed row number of the row containing the cell to inspect
     * @param cellNumber Thr zero indexed row number of the cell containing the text to return
     * @param isHeaderCell Is this a header cell (th) or not (then tr)
     * @return The text from the found cell
     */
    public String getTableCellText(String tableId, int rowNumber, int cellNumber, Boolean isHeaderCell) {
        
        return getTableCell(tableId, rowNumber, cellNumber, isHeaderCell).getText();
    }

    /**
     * Gets a specified cell from a table cell
     * @param tableId The id of the table to inspect
     * @param rowNumber The zero indexed row number of the row containing the cell to return
     * @param cellNumber The zero indexed row number of the cell to return
     * @param isHeaderCell Is this a header cell (th) or not (then tr)
     * @return The found cell
     */
    public WebElement getTableCell(String tableId, int rowNumber, int cellNumber, Boolean isHeaderCell) {

        WebElement table = driver.findElement(By.id(tableId));

        return getTableCell(table, rowNumber, cellNumber, isHeaderCell);
    }

    /**
     * Gets a specified cell from a table cell
     * @param table The table web element
     * @param rowNumber The zero indexed row number of the row containing the cell to return
     * @param cellNumber The zero indexed row number of the cell to return
     * @param isHeaderCell Is this a header cell (th) or not (then tr)
     * @return The found cell
     */
    public WebElement getTableCell(WebElement table, int rowNumber, int cellNumber, Boolean isHeaderCell) {

        String cellType = isHeaderCell ? "th" : "td";

        // get the row
        WebElement tr = table.findElements(By.tagName("tr")).get(rowNumber);

        // get the cell
        WebElement cell = tr.findElements(By.tagName(cellType)).get(cellNumber);

        return cell;
    }

    /**
     * Finds the element with a given id and clicks it
     * @param elemId The id of the element to click
     */
    public void clickElement(String elemId) {
        
        // find the element and click it
        WebElement element = driver.findElement(By.id(elemId));
        element.click();
    }

    /**
     * Checks if a given element has the css property display set to none
     * e.g.
     * element {
     *      display : none;
 *      }
     * @param element The element to check for the css property
     * @return True if the element has display set to none
     */
    public boolean elementHasCssDisplayNone(WebElement element){

        return element.getAttribute("style").matches("display\\s*:\\s*none(;)?");
    }

    /**
     * Checks if an element with given id has the css property display set to none
     * e.g.
     * element {
     *      display : none;
     *      }
     * @param elementId The id of the element to check for the css property
     * @return True if the element has display set to none
     */
    public boolean elementHasCssDisplayNone(String elementId){

        WebElement element = driver.findElement(By.id(elementId));
        sleepQuietly(50);
        return elementHasCssDisplayNone(element);
    }
}