package com.nokia.ent.tooling.reading.pricing.at.drivers.services;

import static com.github.restdriver.clientdriver.RestClientDriver.*;
import static com.github.restdriver.serverdriver.file.FileHelper.*;

import java.util.regex.Pattern;

import com.github.restdriver.clientdriver.ClientDriverRequest;
import com.github.restdriver.clientdriver.ClientDriverRule;

public class EapiQueryDriver {

    private static final String feedsUriBase = "/proxy/eapi/1.x/%s/feeds/private";

    public static void expectGetFeeds(ClientDriverRule clientDriver, String territory) {

        clientDriver.addExpectation(onRequestTo(String.format(feedsUriBase, territory))
                .withMethod(ClientDriverRequest.Method.GET), giveResponse(fromFile("mock-api/get-feeds.json"))).anyTimes();

    }

    public static void expectPutFeeds(ClientDriverRule clientDriver, String territory, String... fragments) {

        Pattern pattern = fragmentsToPattern(fragments);

        clientDriver.addExpectation(onRequestTo(String.format(feedsUriBase, territory))
                .withMethod(ClientDriverRequest.Method.PUT).withBody(pattern, "application/vnd.nokia.ent.feedlist+json"), giveEmptyResponse().withStatus(201));

    }

    private static Pattern fragmentsToPattern(String... fragments) {
        StringBuilder patternString = new StringBuilder();

        for (String fragment : fragments) {
            patternString.append(".*").append(Pattern.quote(fragment));
        }
        patternString.append(".*");

        return Pattern.compile(patternString.toString(), Pattern.DOTALL);
    }
}
